# 📋 BILL UPLOAD + METER INFO + REFERRAL CODE — Implementation Guide

## ✅ What Was Added

Your WattWorth form now captures **three critical new data points**:

### 1. **Electric Bill Upload** (primary)
- Accept: PDF, PNG, JPG, GIF
- File size: Up to 5MB
- Contains: monthly bill amount, utility company, account number, meter info

### 2. **Meter Information** (fallback)
- **Meter Number** (required if no bill)
- **Electric Company** (optional but helpful for rate lookup)
- **Meter Photo** (optional — shows meter number clearly)

### 3. **Referral Code** (customer attribution)
- Format: e.g., "JOHN7K2M"
- Allows customers to credit the friend who referred them
- Links their sign-up to an existing referrer's dashboard

---

## 🎯 Form Logic Flow

```
User uploads bill? ─→ YES ─→ Show "Bill uploaded ✓"
    │                       └─→ Hide meter section
    │
    └─→ NO ─→ Show meter section:
              • Meter number (required)
              • Electric company (optional)
              • Meter photo (optional)
```

**Validation Rules:**
- ✅ Bill upload OR meter info required (at least one)
- ✅ If no bill → meter number is mandatory
- ✅ All other fields same as before (name, email, phone, address)
- ✅ Referral code is optional

---

## 📊 Form Fields Added

### Input Fields:

| Field | Type | Required | Purpose |
|-------|------|----------|---------|
| `bill_upload` | File | If no meter info | Utility bill screenshot/PDF |
| `meter_number` | Text | If no bill | Identifies the property |
| `electric_company` | Text | No | For utility rate lookup |
| `meter_photo` | File | No | Visual confirmation of meter |
| `referral_code` | Text | No | Credits the referring customer |

---

## 📱 UX/UI Details

### Bill Upload Section:
```
📄 Your Electric Bill (or Meter Info)
Upload a screenshot or photo of your bill. If you don't have it, 
we'll use your meter details instead.

[📷 Tap to upload bill or meter photo]
PDF, PNG, JPG (up to 5MB)
```

**When bill is uploaded:**
- File name appears: "✓ electric_bill_2024_01.pdf"
- Box turns green/filled
- Meter section hides

### Meter Details Section (Conditional):
```
[Shows only if NO bill is uploaded]

📸 We need your meter info instead

Meter Number *               Electric Company
[________________]           [________________]

📷 Photo of meter (optional but helpful)
Shows meter number clearly
[Tap to upload]
```

### Referral Code Section:
```
💸 Who referred you? (Optional)

[________________]
e.g., JOHN7K2M

If a friend shared their referral code, 
enter it here to credit them!
```

---

## 🔌 API Integration

### What Gets Sent to Backend

```javascript
{
  "full_name": "John Smith",
  "email": "john@example.com",
  "phone": "(555) 123-4567",
  "address": "123 Main Street",
  "homeowner_status": "own",
  "electric_bill_range": "150-200",
  "roof_shade": "some",
  "notes": "Interested in battery storage",
  
  // NEW FIELDS:
  "bill_upload": "electric_bill_oct_2024.pdf",  // filename or empty
  "meter_number": "12345678",                    // or empty
  "electric_company": "Texas Power & Light",    // or empty
  "meter_photo": "meter_photo.jpg",             // filename or empty
  "referral_code": "JOHN7K2M",                  // or empty
  
  "website_url": ""  // honeypot
}
```

### Backend Processing (Next Steps)

Your `/api/submitLead.js` needs to:

1. **Store file references** in database:
   - Save file names or cloud storage paths
   - Link to lead record in database

2. **Extract meter info** from bill:
   - OCR or manual review of uploaded bill
   - Extract: meter number, company, account number, usage data
   - Use for estimate accuracy

3. **Link referrals**:
   - Look up `referral_code` in referral table
   - Update referrer's "referrals_sent" count
   - Set `referred_by_lead_id` on this lead

4. **Trigger notifications** to Pedro:
   - Email: "New lead with meter photo + bill"
   - Include: meter number, electric company, bill amount
   - Attachment: meter photo + bill upload

---

## 🛠️ Implementation Checklist

### Frontend (✅ DONE)
- [x] Add file upload UI for bill
- [x] Add conditional meter section
- [x] Add meter number, company, photo fields
- [x] Add referral code field
- [x] Add validation (bill OR meter required)
- [x] Add form styling
- [x] Handle file selection and display

### Backend (⏳ NEEDED)
- [ ] Update `/api/submitLead.js` to accept new fields
- [ ] Add file upload handling (cloud storage integration)
- [ ] Add meter info extraction logic
- [ ] Add referral code lookup/linking
- [ ] Update database schema to store:
  - bill_upload_path (URL or file path)
  - meter_number
  - electric_company
  - meter_photo_path
  - referred_by_code
  - referred_by_lead_id
- [ ] Update email templates to include meter info
- [ ] Update SMS templates with meter number
- [ ] Test end-to-end with test submissions

### Database Schema Updates Needed

```javascript
// Lead table - add new columns:
leads {
  ...existing fields...
  
  // Bill/Meter info
  bill_upload_path: String,        // URL to stored bill
  bill_uploaded_at: DateTime,      // when uploaded
  
  meter_number: String,            // e.g., "12345678"
  electric_company: String,        // e.g., "TXU Energy"
  meter_photo_path: String,        // URL to stored photo
  meter_photo_uploaded_at: DateTime,
  
  // Referral attribution
  referred_by_code: String,        // e.g., "JOHN7K2M"
  referred_by_lead_id: UUID,       // Links to referrer
  
  // Data quality
  has_bill: Boolean,               // true if bill uploaded
  has_meter_number: Boolean,       // true if meter number provided
  data_completeness: 0-100,        // Score for data quality
}
```

---

## 📂 File Storage Recommendations

### Option 1: AWS S3 (Recommended)
```javascript
// Store in bucket: wattworth-leads
// Path structure: /bills/{lead_id}/{timestamp}_{filename}
//                 /meters/{lead_id}/{timestamp}_{filename}

const billPath = `s3://wattworth-leads/bills/${leadId}/${Date.now()}_${filename}`;
```

### Option 2: Firebase Storage
```javascript
const billPath = `gs://wattworthapp.appspot.com/bills/${leadId}/${filename}`;
```

### Option 3: Simple approach (if volume is low)
```javascript
// Store on Vercel's /public/uploads (first 100 leads only)
// Later migrate to S3 when needed
const billPath = `/uploads/bills/${leadId}_${filename}`;
```

---

## 📨 Updated Email Templates

### To Pedro (Contractor):

```
Subject: 🔥 New Lead — John Smith — Has Bill + Meter Info

Hi Pedro,

New lead ready to review:

NAME:     John Smith
PHONE:    (555) 123-4567
ADDRESS:  123 Main Street

ELECTRIC DATA:
• Monthly bill: $150–$200 range
• Electric company: Texas Power & Light
• Meter number: 12345678
• Meter photo: [ATTACHED]
• Bill image: [ATTACHED]

OTHER:
• Homeowner: Yes
• Roof shade: Some
• Referred by: Maria Johnson (MARIA7K2M)

Estimate files ready at:
https://cdn.sunloop.io/estimates/{lead_id}.pdf

[Action: Review & Contact]
```

### To Customer (Confirmation):

```
Subject: ✓ Your Solar Estimate Request Received

Hi John,

Thanks for sharing your electric bill and meter info! 📸

We've received:
✓ Your meter number: 12345678
✓ Electric company: Texas Power & Light
✓ Meter photo

A solar specialist will review your info and send you 
a free, personalized estimate within 24 hours.

Referred by: Maria Johnson? 
You entered code MARIA7K2M — thanks for spreading the word!

[View your dashboard]
```

---

## 🚨 Common Issues & Solutions

### Issue 1: File Upload Shows but Doesn't Save
**Problem:** User uploads file, but backend doesn't receive it

**Solution:**
- Currently form sends filename only, not the actual file
- Need to implement FormData + multipart/form-data for actual file upload
- See "Next Steps: FormData Implementation" below

### Issue 2: Meter Section Doesn't Show
**Problem:** Meter details stay hidden even without bill

**Solution:**
- Check browser console for JavaScript errors
- Verify DOMContentLoaded event listener fired
- Test: `document.getElementById('meterDetailsSection').style.display = 'block'`

### Issue 3: Referral Code Not Linking
**Problem:** Customer enters code but it doesn't credit the referrer

**Solution:**
- Backend needs to look up code in referral table
- Match code to existing lead/customer
- Set `referred_by_lead_id` on new lead
- Update referrer's earnings in dashboard

---

## 🔧 Next Steps: FormData Implementation

### Current State (Names Only):
```javascript
// Right now we send filename as string
body: JSON.stringify(payload)
```

### Needed (Actual Files):
```javascript
// Need to send FormData with actual files

const formData = new FormData();
formData.append('full_name', payload.full_name);
formData.append('email', payload.email);
// ... all other fields ...

if (document.getElementById('billUpload').files[0]) {
  formData.append('bill_upload', document.getElementById('billUpload').files[0]);
}
if (document.getElementById('meterPhoto').files[0]) {
  formData.append('meter_photo', document.getElementById('meterPhoto').files[0]);
}

// Send with FormData (not JSON)
const response = await fetch('/api/submitLead', {
  method: 'POST',
  body: formData,  // NOT JSON.stringify
  // NO Content-Type header (browser sets multipart/form-data)
});
```

**This needs updates in:**
1. `index.html` — submitLeadForm fetch call
2. `/api/submitLead.js` — parse multipart/form-data (use `busboy` or `formidable`)
3. Cloud storage integration — upload files to S3/Firebase

---

## 📊 Data Quality Improvements

With these new fields, SunLoop can now:

✅ **More accurate estimates:**
- Actual meter data instead of guesses
- Verify electric company rates
- Account for time-of-use pricing

✅ **Better lead scoring:**
- Has bill = higher quality lead (+10 points)
- Has meter photo = higher quality (+5 points)
- Referral = trusted source (+3 points)

✅ **Faster contractor follow-up:**
- Pedro has all data upfront
- No back-and-forth emails for info
- Can prep proposal before first call

✅ **Fraud prevention:**
- Meter number verification
- Bill amount cross-check
- Referral tracking

---

## 🎯 Success Metrics

Track these after launch:

| Metric | Target | Purpose |
|--------|--------|---------|
| % leads with bill | 40%+ | Data quality |
| % leads with meter | 20%+ | Fallback usage |
| % leads with referral | 10-15% | Program engagement |
| Lead quality score | +15 points avg | Better estimates |
| Pedro response time | -30% faster | More data upfront |

---

## 📝 Summary

### What Changed:
✅ Added electric bill upload (primary source)
✅ Added meter details fallback (if no bill)
✅ Added referral code input (attribution)
✅ Added smart conditional logic (show/hide based on bill)
✅ Added validation (bill OR meter required)

### What's Ready:
✅ Frontend form UI
✅ Client-side validation
✅ File handling functions
✅ Conditional visibility

### What's Next:
⏳ Backend file upload handling
⏳ Database schema updates
⏳ Cloud storage integration
⏳ Referral code linking
⏳ Email template updates
⏳ API endpoint modifications

### Impact:
🚀 Better data = better estimates
🚀 Faster contractor response
🚀 More qualified leads
🚀 Improved referral tracking

---

## 💬 Questions?

- **File upload not working?** Check the FormData implementation section above
- **Meter section won't show?** Check browser console for JS errors
- **Referral code not linking?** Implement referral lookup in backend
- **Want to change fields?** Let me know and I'll update the form

**Your form is now a lead quality powerhouse!** 🚀

---

*Last updated: June 22, 2026*
*WattWorth Platform × SunLoop Engine*
