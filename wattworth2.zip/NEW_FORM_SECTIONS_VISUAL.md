# 📱 NEW FORM SECTIONS — Visual Guide

## The Updated Form Structure

```
┌─────────────────────────────────────────────────────┐
│          Your Solar Savings                         │
│  Answer a few questions to see how much you could   │
│  save with solar. Takes about 60 seconds.           │
└─────────────────────────────────────────────────────┘

SECTION 1: CONTACT INFO (unchanged)
┌─────────────────────────────────────────────────────┐
│ Full Name              │  Email Address              │
│ [John Smith________]   │  [john@example.com_____]   │
│ Phone Number          │  Home Address               │
│ [(555) 123-4567___]   │  [123 Main St___________]   │
└─────────────────────────────────────────────────────┘

SECTION 2: QUALIFICATION (unchanged)
┌─────────────────────────────────────────────────────┐
│ DO YOU OWN OR RENT?                                 │
│ ○ I own my home    ○ I rent                         │
│                                                     │
│ AVERAGE MONTHLY ELECTRIC BILL?                      │
│ ○ Under $100  ○ $100–$150  ○ $150–$200  ○ $200+    │
│                                                     │
│ HOW MUCH SHADE ON YOUR ROOF?                        │
│ ○ Little to no shade  ○ Some shade  ○ Not sure     │
│                                                     │
│ ANYTHING ELSE WE SHOULD KNOW? (Optional)            │
│ [e.g., interested in battery storage...________]    │
└─────────────────────────────────────────────────────┘

[NEW SECTION] SECTION 3: ELECTRIC BILL / METER INFO
┌─────────────────────────────────────────────────────┐
│ 📄 YOUR ELECTRIC BILL (or Meter Info)               │
│ Upload a screenshot or photo of your bill. If you   │
│ don't have it, we'll use your meter details instead.│
│                                                     │
│ ┌──────────────────────────────────────────────┐   │
│ │ 📷 Tap to upload bill or meter photo        │   │
│ │ PDF, PNG, JPG (up to 5MB)                    │   │
│ │ ✓ electric_bill_oct_2024.pdf                 │   │
│ └──────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────┘

[CONDITIONAL] SHOWS ONLY IF NO BILL UPLOADED:
┌─────────────────────────────────────────────────────┐
│ 📸 We need your meter info instead                  │
│                                                     │
│ Meter Number *          │  Electric Company        │
│ [12345678_________]     │  [Texas Power & Light]   │
│                                                     │
│ ┌──────────────────────────────────────────────┐   │
│ │ 📷 Photo of meter (optional but helpful)    │   │
│ │ Shows meter number clearly                   │   │
│ │ [Tap to upload]                              │   │
│ └──────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────┘

[NEW SECTION] SECTION 4: REFERRAL CODE
┌─────────────────────────────────────────────────────┐
│ 💸 WHO REFERRED YOU? (Optional)                     │
│ [JOHN7K2M_____________________]                     │
│ If a friend shared their referral code, enter it   │
│ here to credit them!                                │
└─────────────────────────────────────────────────────┘

SECTION 5: CONSENT (unchanged)
┌─────────────────────────────────────────────────────┐
│ ✓ By submitting this form, you agree to be         │
│   contacted by solar specialists. We never sell    │
│   your data. You can unsubscribe anytime.          │
└─────────────────────────────────────────────────────┘

SECTION 6: SUBMIT (unchanged)
┌─────────────────────────────────────────────────────┐
│      [ Get my solar estimate → ]                    │
└─────────────────────────────────────────────────────┘
```

---

## 📱 Mobile Experience Flow

### Scenario 1: User HAS Electric Bill

```
┌─────────────────────┐
│ 📄 Your Electric    │
│ Bill (or Meter...)  │
│                     │
│ ┌─────────────────┐ │
│ │ 📷 Tap to       │ │
│ │ upload...       │ │
│ └─────────────────┘ │
└─────────────────────┘
        ↓ (tap)
     [Photo picker opens]
        ↓ (select bill photo)
┌─────────────────────┐
│ ┌─────────────────┐ │
│ │ 📷 Tap to       │ │
│ │ upload...       │ │
│ │ ✓ bill_oct.pdf  │ │ ← Shows filename
│ └─────────────────┘ │
│                     │
│ [Meter section      │ ← HIDES automatically
│  stays hidden]      │
└─────────────────────┘
        ↓ (scroll down)
┌─────────────────────┐
│ 💸 WHO REFERRED YOU?│
│ [_____________]     │ (optional)
│                     │
│ ✓ Consent           │
│ [ Submit >>>]       │
└─────────────────────┘
```

### Scenario 2: User HAS NO Bill (Meter Fallback)

```
┌─────────────────────┐
│ 📄 Your Electric    │
│ Bill (or Meter...)  │
│                     │
│ ┌─────────────────┐ │
│ │ 📷 Tap to       │ │
│ │ upload...       │ │
│ └─────────────────┘ │
└─────────────────────┘
        ↓ (skip / swipe down)
        ↓ (don't upload)
┌─────────────────────┐
│ [Meter section      │
│  SHOWS because no   │
│  bill uploaded]     │
│                     │
│ 📸 We need your     │
│ meter info instead  │
│                     │
│ Meter Number *      │
│ [__________] ← REQ'd│
│                     │
│ Electric Company    │
│ [___________] ← OPT │
│                     │
│ 📷 Meter photo      │
│ [Tap to upload]     │
│ ← Optional          │
└─────────────────────┘
        ↓ (fill in meter #)
┌─────────────────────┐
│ [Form validates     │
│  meter number = OK  │
│  Can proceed ✓]     │
│                     │
│ 💸 WHO REFERRED YOU?│
│ [_____________]     │
│                     │
│ ✓ Consent           │
│ [ Submit >>>]       │
└─────────────────────┘
```

---

## 🎯 Key User Flows

### Flow 1: "I have my electric bill"
1. User scrolls to "Bill" section
2. Taps upload box
3. Selects bill photo/PDF from phone
4. Filename appears ✓
5. Meter section auto-hides
6. User continues to referral code
7. Submits form

### Flow 2: "I don't have my bill but know meter number"
1. User scrolls to "Bill" section
2. Doesn't upload anything
3. Scrolls down
4. Meter section appears ("We need your meter info")
5. Enters meter number (required)
6. Optionally enters electric company
7. Optionally uploads meter photo
8. Continues to referral code
9. Submits form

### Flow 3: "I don't have bill OR meter number"
1. User scrolls to "Bill" section
2. Doesn't upload bill
3. Scrolls down, sees meter section
4. Meter number is required *
5. User can't proceed without it
6. Error: "Please provide your meter number"
7. User either:
   - Goes back and uploads bill, OR
   - Enters meter number from their meter

---

## 📊 Validation Logic

```
┌─────────────────────────────────┐
│   Form Submission Validation    │
└─────────────────────────────────┘
         ↓
   [Check bill uploaded?]
    /                 \
  YES               NO
   │                 │
   │          [Check meter number?]
   │           /              \
   │         YES              NO
   │          │               │
   │          ✓              ❌ ERROR
   │         OK          "Provide meter #"
   │          │
   └──────────┴──→ [Check other fields]
                   • Name ✓
                   • Email ✓
                   • Phone ✓
                   • Address ✓
                        │
                   [All good?]
                   /         \
                 YES          NO
                  │           │
                  ✓          ❌ ERROR
               SUBMIT    "Fill required fields"
```

---

## 🎨 Visual States

### Normal State (Bill Upload Box)
```
┌─────────────────────────────────────┐
│ 📷 Tap to upload bill or meter photo│
│ PDF, PNG, JPG (up to 5MB)           │
│                                     │
│ [Box has dashed border, light green │
│  background, slightly rounded]      │
└─────────────────────────────────────┘
```

### Hover State
```
┌─────────────────────────────────────┐
│ 📷 Tap to upload bill or meter photo│
│ PDF, PNG, JPG (up to 5MB)           │
│                                     │
│ [Border becomes solid green,        │
│  background becomes brighter green]  │
└─────────────────────────────────────┘
```

### Filled State
```
┌─────────────────────────────────────┐
│ 📷 Tap to upload bill or meter photo│
│ PDF, PNG, JPG (up to 5MB)           │
│ ✓ electric_bill_october_2024.pdf    │
│                                     │
│ [Border solid green, filled green   │
│  background, filename shown below]   │
└─────────────────────────────────────┘
```

### Error State (If meter number required but not provided)
```
┌─────────────────────────────────────┐
│ ❌ Please provide your meter number │
│    if you don't have your bill.     │
│                                     │
│ [Red/error styling on meter field]  │
│ Meter Number *                      │
│ [________________] ← Error highlight│
└─────────────────────────────────────┘
```

---

## 💾 What Gets Stored

### In Database:
```
Lead: john_smith_123
{
  full_name: "John Smith",
  email: "john@example.com",
  phone: "(555) 123-4567",
  address: "123 Main Street",
  
  // NEW: Bill/Meter
  bill_upload: "s3://bucket/bills/uuid/bill_oct_2024.pdf",
  meter_number: "12345678",
  electric_company: "Texas Power & Light",
  meter_photo: "s3://bucket/meters/uuid/meter_photo.jpg",
  
  // NEW: Referral
  referred_by_code: "JOHN7K2M",
  referred_by_lead_id: "john_referrer_456",
  
  // Metadata
  bill_uploaded_at: "2024-10-15T14:23:00Z",
  meter_photo_uploaded_at: "2024-10-15T14:25:00Z",
}
```

---

## 📧 What Pedro Sees (Email)

```
┌────────────────────────────────────────┐
│ New Lead: John Smith                   │
│ San Antonio, TX                        │
├────────────────────────────────────────┤
│                                        │
│ CONTACT:                               │
│ Phone: (555) 123-4567                  │
│ Email: john@example.com                │
│ Address: 123 Main Street               │
│                                        │
│ ELECTRIC DATA:                         │
│ ✓ Bill uploaded: YES                   │
│ ✓ Meter number: 12345678               │
│ ✓ Company: Texas Power & Light         │
│ ✓ Meter photo: [ATTACHED]              │
│                                        │
│ QUALIFICATIONS:                        │
│ • Homeowner: YES                       │
│ • Monthly bill: $150–$200              │
│ • Roof shade: Some                     │
│                                        │
│ REFERRAL:                              │
│ Referred by: John Doe (JOHN7K2M)       │
│                                        │
│ [View in Dashboard] [Call Now]         │
└────────────────────────────────────────┘
```

---

## ✅ Success Indicators

When implementation is working correctly, you'll see:

✅ **Bill uploaded** → Meter section hides
✅ **No bill** → Meter section shows (meter number required)
✅ **Meter number filled** → Can submit
✅ **Referral code entered** → Links to correct referrer
✅ **Email to Pedro** → Includes meter info + attachments
✅ **Dashboard** → Shows bill status, meter number, referrer name

---

## 🎯 Next Step

The form is ready! Next, you need to:

1. **Backend updates** (see BILL_METER_REFERRAL_GUIDE.md)
2. **File upload handling** (FormData + cloud storage)
3. **Referral code linking** (database lookup)
4. **Email template updates** (include meter/bill info)

**Current form is live and collecting data — just names only for now.** 🚀

