# 🎯 LEAD GENERATION STRATEGY — How WattWorth Brings in Customers

## The Big Picture: Three Layers of Customer Acquisition

```
┌─────────────────────────────────────────────────────────────┐
│                    CUSTOMER JOURNEY                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ LAYER 1: AWARENESS (Top of Funnel)                         │
│ ├─ Paid Ads (Facebook, Google, Instagram, TikTok)          │
│ ├─ Organic (Blog, SEO, YouTube)                            │
│ ├─ Referral (Word-of-mouth, $1,000 rewards)                │
│ └─ Partnership (Solar installers, home improvement sites)   │
│        ↓                                                    │
│ LAYER 2: ENGAGEMENT (Middle of Funnel)                     │
│ ├─ Landing page (WattWorth hero section)                    │
│ ├─ Trust signals ("No calls", "60 seconds", "Free")        │
│ ├─ Hero CTA ("Check my savings")                           │
│ └─ FOMO ("Homeowners in your area save $2,200/year")       │
│        ↓                                                    │
│ LAYER 3: CONVERSION (Bottom of Funnel)                     │
│ ├─ The Form (Your index.html with bill/meter capture)      │
│ ├─ Questions (own/rent, bill, shade, referral)            │
│ ├─ Friction reduction (60 seconds, no phone required)      │
│ └─ Validation (Bill OR meter → confirms real homeowner)    │
│        ↓                                                    │
│ LAYER 4: FULFILLMENT (Post-Conversion)                     │
│ ├─ Instant PDF proposal                                     │
│ ├─ Saved quote link (return-to-quote)                      │
│ ├─ Referral dashboard (earn $1,000)                        │
│ └─ Contractor contact (Pedro calls within 24 hours)        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## **LAYER 1: AWARENESS — How to Bring People to Your Site**

### **Option A: PAID ADVERTISING** (You control the budget)

#### **Facebook Ads** (Best for conversions)
```
Budget: $500-$1,000/month
Target: 35–65 year old homeowners in Texas
Messaging: "See your solar savings in 60 seconds"
Landing page: Your WattWorth hero section
Expected: 100-300 clicks/month → 5-20 leads/month
Cost per lead: $50-$200 (varies by market)

Visual: 
- Show real homeowner with high bill
- "$2,200/year in savings" headline
- CTA: "Check my savings"
```

#### **Google Ads** (High intent, expensive)
```
Budget: $1,000-$3,000/month
Keywords: 
- "solar panels near me"
- "solar savings calculator"
- "how much do solar panels cost"
- "solar panel installation [city]"

Expected: 20-50 clicks/month → 2-8 leads/month
Cost per click: $1.50-$3.00
Cost per lead: $200-$500 (lower volume, higher quality)
```

#### **Instagram/TikTok Ads** (Brand building, volume)
```
Budget: $300-$1,000/month
Target: 25–45 year old environmentally conscious homeowners
Messaging: "Make money while saving the planet"
Expected: 50-200 clicks/month → 3-15 leads/month
Cost per lead: $50-$150

Content angle:
- Before/after (high electric bill → solar system)
- Referral success stories ("I earned $1,000 in 3 months")
- Educational (why solar matters, tax credits)
```

---

### **Option B: ORGANIC TRAFFIC** (Free, takes time)

#### **SEO (Google Search)**
```
Timeline: 3-6 months to see results
Topics to target:
- "Solar panels [your city]"
- "How much do solar panels cost Texas"
- "Solar tax credit 2024"
- "Best solar companies [your area]"

How to get traffic:
1. Blog posts on these topics
2. Link from other solar sites
3. Local SEO (Google My Business)
4. YouTube videos ("Are solar panels worth it?")

Expected: 20-50 organic visits/month → 1-5 leads/month
```

#### **Referral Program** (Your customers bring friends)
```
Your current setup:
- Customer signs up → $50 reward
- Customer gets estimate → $100 reward  
- Customer installs solar → $1,000 reward
- They share their unique link with friends

Expected viral growth:
Month 1: 5 referrals (from early customers)
Month 2: 15 referrals (word spreads)
Month 3: 30+ referrals (compounding growth)

This becomes 10-30% of your monthly leads for FREE
```

#### **Partnerships** (Other websites send you leads)

**Solar Comparison Sites:**
- EnergySage, SolarReviews, etc.
- They get leads, take 30-50% commission
- You get verified leads (pay per lead)

**Home Improvement Sites:**
- Angie's List, HomeAdvisor
- Similar model (pay per lead)

**Local Installers:**
- Pedro's network (Solar Pros / Freedom Forever)
- They refer homeowners → get commission
- Low cost, high conversion (pre-qualified)

---

## **LAYER 2: ENGAGEMENT — Landing Page Messaging**

Your WattWorth landing page does this:

```
┌───────────────────────────────────────────────┐
│ Hero Section (First thing they see)            │
│                                               │
│ "See your real solar savings in               │
│  under 60 seconds. No calls, no reps,         │
│  no obligation."                              │
│                                               │
│ [Trust Pills] ✓ No calls  ✓ Free proposal     │
│              ✓ 60 seconds ✓ Earn $1,000       │
│                                               │
│ "$2,200/year in savings" (location stat)      │
│ "Homeowners in your area are saving up to..." │
│                                               │
│ [CTA Button] "Check my savings →"             │
└───────────────────────────────────────────────┘
        ↓ (They click)
        ↓
┌───────────────────────────────────────────────┐
│ Modal Form Appears (The Funnel)                │
│                                               │
│ Step 1: Name, Email, Phone, Address           │
│ Step 2: Own/Rent? Bill range? Roof shade?     │
│ Step 3: [NEW] Upload bill or meter info       │
│ Step 4: [NEW] Referral code (who sent you?)   │
│                                               │
│ Messaging: "Your solar specialist will        │
│            contact you within 24 hours"       │
│                                               │
│ [Submit Button] "Get my solar estimate →"     │
└───────────────────────────────────────────────┘
```

**Key messaging elements:**
- ✅ **"60 seconds"** — Low time commitment
- ✅ **"No calls required"** — Reduces friction
- ✅ **"Free proposal"** — No hidden costs
- ✅ **"Earn $1,000"** — Referral incentive
- ✅ **Location stat** — Social proof ("people in your area")
- ✅ **Bill upload** — Proves they're serious (filters tire-kickers)

---

## **LAYER 3: CONVERSION — The Form & Your New Sections**

### **Why the Bill + Meter + Referral Sections Matter**

```
BEFORE (Old Form):
- Name, email, phone, address
- Own/rent, bill range, roof shade, notes
- Result: 60% of leads are tire-kickers (just curious, not serious)

AFTER (Your New Form):
- All of above +
- [NEW] Upload electric bill or meter number ← Filters out non-serious
- [NEW] Electric company name ← Shows they know their utility
- [NEW] Meter photo (optional) ← Visual proof of property
- [NEW] Referral code ← Tracks where they came from

Result:
- 80%+ of leads are serious homeowners
- Pedro can prep estimate before first call
- Referral tracking shows your best marketing channels
- Lead quality score increases by 25+ points
```

### **Validation Forces Quality**

```
User submits form...

Check 1: Do they have BILL or METER NUMBER?
├─ YES → Continue
└─ NO → Error: "Please upload bill or provide meter number"

Check 2: If they provided METER NUMBER or PHOTO, 
         do they have ELECTRIC COMPANY?
├─ YES → Continue
└─ NO → Error: "Please tell us your electric company"

Result: You ONLY get leads with:
✓ Contact info (can reach them)
✓ Property verification (bill or meter)
✓ Utility company (can lookup rates)
✓ Either bill OR meter (can calculate savings)
```

---

## **LAYER 4: FULFILLMENT — What Happens After They Submit**

### **Immediate (Within 1 minute)**
```
1. Form submitted → Backend processes
2. Lead stored in database
3. PDF proposal generated (using their data)
4. Lead scoring applied (0-100)
5. Tier assigned (HOT/WARM/COOL/COLD)
6. Customer gets confirmation email + PDF
7. Pedro gets alert email (if HOT lead)
```

### **Within 24 hours**
```
Pedro (or assigned rep) calls the lead
- Has: Name, phone, address, electric bill/meter number
- Can say: "Hi John, I saw you're interested in solar.
            Your bill shows you could save $150/month..."
- Already has their estimate ready
- Can discuss pricing & financing options
```

### **Within 7 days**
```
Customer sees results:
- Saved quote link (return anytime)
- Referral dashboard (see their earning potential)
- Follow-up emails with financing options
- SMS reminders ("Get your free proposal")
```

### **Within 30 days**
```
If customer has solar installed:
- Gets $1,000 referral reward (if they referred someone)
- Updates dashboard with installation photos
- Can share their savings with others
- Starts earning referral rewards again
```

---

## **YOUR MARKETING FUNNEL — The Numbers**

### **Example: $500/month ad spend**

```
┌────────────────────────────────────┐
│ MONTHLY MARKETING SPEND: $500      │
├────────────────────────────────────┤
│                                    │
│ Ad Spend Allocation:               │
│ • Facebook Ads: $250               │
│ • Google Ads: $150                 │
│ • Organic (free): --               │
│ • Referrals (free): --             │
│                                    │
│ Traffic Generated:                 │
│ • Facebook: 50 clicks              │
│ • Google: 30 clicks                │
│ • Organic: 20 visits               │
│ • Referral: 5 visits               │
│ ────────────────────────────────   │
│ TOTAL: 105 visits                  │
│                                    │
│ Conversion Rate: 10% (typical)     │
│ ────────────────────────────────   │
│ LEADS GENERATED: 10-12/month       │
│                                    │
│ Cost Per Lead: $42-50              │
│                                    │
│ Lead Quality:                      │
│ • HOT (will install): 2-3          │
│ • WARM (probably will): 4-5        │
│ • COOL (maybe): 3-4                │
│                                    │
│ Expected Conversions (to install): │
│ • 3-5 customers/month              │
│ • @ $5,000 avg profit = $15-25K/mo │
│                                    │
└────────────────────────────────────┘
```

---

## **CHANNEL COMPARISON — Where to Spend Your Money**

| Channel | Budget | Leads/Mo | Cost/Lead | Quality | Setup Time | Best For |
|---------|--------|----------|-----------|---------|------------|----------|
| **Facebook Ads** | $300-500 | 8-12 | $40-60 | Medium | 1 day | Volume, brand awareness |
| **Google Ads** | $500-1000 | 3-5 | $150-300 | High | 1 day | High-intent searchers |
| **Instagram/TikTok** | $200-500 | 5-10 | $40-100 | Medium | 3 days | Younger, eco-conscious |
| **Organic (SEO)** | Free | 2-5 | $0 | High | 3-6 months | Long-term, sustainable |
| **Referrals** | Free (rewards) | 2-8 | Cost of $1,000 reward | Highest | Ongoing | Viral growth |
| **Local Partnerships** | 20-50% commission | 5-15 | $0 upfront | High | 2 weeks | Pre-qualified leads |

---

## **YOUR SPECIFIC SITUATION (Kacy + Pedro)**

### **The Model:**
```
YOU (Kacy/WattWorth):
├─ Build the landing page ✓
├─ Run paid ads (Facebook, Google, TikTok)
├─ Manage the marketing funnel
└─ Drive traffic to the form

PEDRO (Solar Pros/Freedom Forever):
├─ Receives qualified leads
├─ Closes the sale & installs
├─ Pays you commission OR
└─ You split referral rewards with him

The Form (index.html):
├─ Captures contact info
├─ Validates they're serious (bill/meter required)
├─ Tracks who referred them
├─ Feeds qualified leads to Pedro
└─ Tracks referral payouts ($50/$100/$1,000)
```

### **Revenue Streams:**

**Option 1: You get paid per lead**
```
- Pedro pays you $100-200 per qualified lead
- You run ads → generate 10 leads/month
- = $1,000-2,000/month from Pedro
- Plus: If customer installs, you get referral commission
```

**Option 2: You get referral commission**
```
- Customer refers friend → signs up → completes estimate → installs
- You earn: $50 + $100 + $1,000 = $1,150 per referral
- 10 referrals/month = $11,500/month
- You share % with Pedro if he installs them
```

**Option 3: Hybrid (Recommended)**
```
- Pedro pays you $150 per lead you send him
- If lead installs → you split the referral rewards
  (e.g., you get $1,000, Pedro gets $150)
- Example: 10 leads/month × 30% close rate (3 installs)
  = $1,500 (leads) + $3,000 (referral splits) = $4,500/month
```

---

## **WHAT YOU NEED TO DO (Action Items)**

### **SHORT-TERM (This week)**
- [ ] Deploy updated index.html (with bill/meter/referral)
- [ ] Set up Google Ads account
- [ ] Create 3-5 ad creative (hero image + bill savings stat)
- [ ] Set budget: Start with $300-500/month

### **MEDIUM-TERM (This month)**
- [ ] Launch Facebook ads ($200-300/month)
- [ ] Track conversions (which ads work best)
- [ ] Optimize landing page based on visitor behavior
- [ ] Test referral messaging in ads
- [ ] Set up referral dashboard for customers

### **LONG-TERM (3 months)**
- [ ] Expand to TikTok/Instagram ads
- [ ] Build organic traffic (SEO, blog)
- [ ] Develop referral viral loops
- [ ] Analyze ROI by channel
- [ ] Scale winning channels

---

## **QUICK START: FACEBOOK ADS EXAMPLE**

### **Ad Creative (What They See)**

```
┌─────────────────────────────┐
│ [Image: Happy homeowner     │
│  with low electric bill]    │
│                             │
│ HEADLINE:                   │
│ "Homeowners in [City] are   │
│  saving $2,200/year"        │
│                             │
│ TEXT:                       │
│ "See your solar savings in  │
│  60 seconds. Free proposal. │
│  No calls required."        │
│                             │
│ [BUTTON] Get My Estimate    │
└─────────────────────────────┘
```

### **Targeting**
```
Age: 35-65
Location: Texas (or your state)
Interests: Home improvement, solar, energy savings
Income: $75K+
Homeowners only
```

### **Budget & Results (First Month)**
```
Daily budget: $10
Monthly budget: $300
Expected results:
- 2,000 impressions
- 50 clicks
- 5 leads
- Cost per lead: $60
```

---

## **THE BOTTOM LINE**

### **Your Role (Kacy):**
1. **Traffic generation** — Run ads or organic campaigns
2. **Lead capture** — The form captures bill/meter/referral
3. **Lead management** — Track quality, optimize messaging
4. **Referral tracking** — Monitor who refers whom

### **Pedro's Role:**
1. **Lead conversion** — Calls leads, closes deals
2. **Installation** — Installs solar systems
3. **Referral fulfillment** — Confirms installations for payout

### **The Form's Role:**
1. **Qualify** — Bill/meter requirement filters serious leads
2. **Convert** — Trust signals ("60 sec", "free") reduce friction
3. **Track** — Referral code shows where customers came from
4. **Score** — Bill + meter data helps estimate quality

---

## **Example: $500/Month Ad Budget → Real Results**

```
Month 1:
├─ Spend: $500
├─ Leads: 10
├─ Quality: WARM (some will install)
└─ Cost/lead: $50

Month 2:
├─ Spend: $500
├─ Leads: 12 (optimization working)
├─ Quality: Higher (referrals starting)
├─ Installs: 2-3 (from Month 1 leads)
└─ Referral earnings: $2,000-3,000

Month 3:
├─ Spend: $500
├─ Leads: 15 (viral growth kicking in)
├─ Quality: Very high (referral network growing)
├─ Installs: 4-5
├─ Referral earnings: $4,000-5,000
└─ Organic/referral leads: Now 30% of total

By Month 6:
├─ Leads: 20+/month (from ads + referrals)
├─ Install rate: 30-40% (increasing)
├─ Monthly revenue: $5,000-10,000+
└─ ROI: 10x on ad spend
```

---

## **Summary: YOU CONTROL THE TRAFFIC**

✅ **Paid ads** (Facebook, Google, TikTok) — You pay for clicks
✅ **Organic** (SEO, blog, YouTube) — Free but takes time
✅ **Referrals** — Free, exponential growth, highest conversion
✅ **Partnerships** — Other websites send leads (commission-based)

**The form** just sits there and converts whoever you send. Your job is **driving the traffic**.

**Questions?** Let me know which channel you want to start with!

---

*Last updated: June 22, 2026*
*WattWorth Marketing Strategy × SunLoop Lead Engine*
